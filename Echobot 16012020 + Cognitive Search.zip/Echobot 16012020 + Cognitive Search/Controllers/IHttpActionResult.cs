﻿namespace EchoBot.Controllers
{
    public interface IHttpActionResult
    {
    }
}