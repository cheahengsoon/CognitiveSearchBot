﻿namespace EchoBot.Controllers
{
    public class ApiController
    {
    }
}