﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.ServiceModel.Syndication;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Xsl;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Azure;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Microsoft.Toolkit.Parsers.Rss;
using Newtonsoft.Json.Linq;

namespace EchoBot.Bots
{
    public class BackUp : ActivityHandler
    {
        private ILogger<BackUp> _logger;
        private IBotServices _botServices;

        private const string CosmosServiceEndpoint = "https://cosmodb2.documents.azure.com:443/";
        private const string CosmosDBKey = "RYvAymUKCfvbczmjluwJfOo8UUMPO94e88Eu2RArV3tYXB9WDNDR4mjQx6mfBD1Hm7fJKAWaT2fk6xo5vik0WQ==";
        private const string CosmosDBDatabaseName = "ToDoList";
        private const string CosmosDBCollectionName = "Items";

        private static readonly CosmosDbStorage query = new CosmosDbStorage(new CosmosDbStorageOptions
        {
            AuthKey = CosmosDBKey,
            CollectionId = CosmosDBCollectionName,
            CosmosDBEndpoint = new Uri(CosmosServiceEndpoint),
            DatabaseId = CosmosDBDatabaseName,
        });

        public BackUp(IBotServices botServices, ILogger<BackUp> logger)
        {
            _logger = logger;
            _botServices = botServices;
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {


            // First, we use the dispatch model to determine which cognitive service (LUIS or QnA) to use.
            var recognizerResult = await _botServices.Dispatch.RecognizeAsync(turnContext, cancellationToken);

            // Top intent tell us which cognitive service to use.
            var topIntent = recognizerResult.GetTopScoringIntent();

            // Next, we call the dispatcher with the top intent.
            await DispatchToTopIntentAsync(turnContext, topIntent.intent, recognizerResult, cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            //  const string WelcomeText = "Type a greeting, or a question about the weather to get started.";

            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Welcome to Data@Work Agent." + "\n" + " What can I help you?"), cancellationToken);
                }
            }
        }

        private async Task DispatchToTopIntentAsync(ITurnContext<IMessageActivity> turnContext, string intent, RecognizerResult recognizerResult, CancellationToken cancellationToken)
        {
            switch (intent)
            {

                case "None":
                    //await ProcessRSSAsync(turnContext, cancellationToken);
                    await ProcessRSSAsync(turnContext, recognizerResult.Properties["luisResult"] as LuisResult, intent, cancellationToken);
                    break;
                case "QnAmaker":
                    await ProcessSampleQnAAsync(turnContext, cancellationToken);
                    break;
                default:
                    _logger.LogInformation($"Unrecognized intent: {intent}.");
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Unrecognized intent: {intent}."), cancellationToken);
                    break;
            }
        }

        private async Task ProcessRSSAsync(ITurnContext<IMessageActivity> turnContext, LuisResult luisResult, string intent, CancellationToken cancellationToken)
        {

            await turnContext.SendActivityAsync("intent recognize" + intent);

            var intentresut = intent;
            await turnContext.SendActivityAsync("Get LUIS Entity");
            await turnContext.SendActivityAsync(string.Join("\t", luisResult.Entities.Select((entityObj) => entityObj.Entity)));
            var entityfound = string.Join("\t", luisResult.Entities.Select((entityObj) => entityObj.Entity));

            string spxurl = @"https://intra.aspac.kpmg.com/sites/sg/daw/_layouts/15/srchrss.aspx?k=*%20ListId:7BC0F2C3-6366-48B8-B88A-8738BE1F9C31";
            ////---------------------------------------------------------------------------------------------
            //22112019

            var credentials = new NetworkCredential("engsooncheah@kpmg.com.sg", "Kpmg@singapore1331", "sg.kworld.kpmg.com");

            var handler = new HttpClientHandler { Credentials = credentials, UseDefaultCredentials = false };
            var client = new HttpClient(handler);

            client.BaseAddress = new Uri("https://intra.aspac.kpmg.com/sites/sg/daw/");
            HttpResponseMessage resp = client.GetAsync("_layouts/15/srchrss.aspx?k=*%20ListId:7BC0F2C3-6366-48B8-B88A-8738BE1F9C31").Result;

            string respString = resp.Content.ReadAsStringAsync().Result;


            if (resp.StatusCode == HttpStatusCode.OK)
            {
                await turnContext.SendActivityAsync("Connected");
                try
                {
                    ////ES26112019 Work but the RSS formattting
                    XmlDocument doc = new XmlDocument();
                    doc.Load(respString);

                    XmlNodeList xnList = doc.SelectNodes("/rss/channel/item");

                    var attachments = new List<Attachment>();

                    foreach (XmlNode xn in xnList)
                    {
                        string title = xn["title"].InnerText;
                        string link = xn["link"].InnerText;
                        string textdesc = xn["description"].InnerText;

                        string newlink = link.Replace("\r\n", "");

                        string desc = xn["description"].InnerText;
                        string newdesc = Regex.Replace(desc, @"[<][^>]*[>]", string.Empty);
                        // TextBox2.Text += "Title: " + title + " link: " + link + " Description: " + newdesc + "\n\n";)

                        // Hero Card
                        var heroCard = new HeroCard(
                            title: title.ToString(),
                            text: textdesc.ToString(),

                                                           buttons: new CardAction[]
                                                           {
                                                   new CardAction(ActionTypes.OpenUrl,"LINK",value:newlink)
                                                           }
                            ).ToAttachment();
                        attachments.Add(heroCard);

                    }
                    var reply = MessageFactory.Carousel(attachments);
                    await turnContext.SendActivityAsync(reply);

  

                }
                catch (Exception ex)
                {
                    await turnContext.SendActivityAsync(ex.ToString());
                }

            }




            await turnContext.SendActivityAsync("Process Sharepoint sample 2");
            try
            {
                //string spurl = @"https://intra.aspac.kpmg.com/sites/sg/daw/_layouts/15/srchrss.aspx?k=*%20ListId:7BC0F2C3-6366-48B8-B88A-8738BE1F9C31";
                string spurl = "https://intra.aspac.kpmg.com/sites/sg/daw/_api/lists/getbytitle('data@work')/Items?%20$select=Title,Description,Follow&$filter=Keywords%20eq%20%27bloomberg%27";
                XmlSecureResolver resolver = new XmlSecureResolver(new XmlUrlResolver(), spurl);
                resolver.Credentials = new NetworkCredential("engsooncheah@kpmg.com.sg", "Kpmg@singapore1331", "sg.kworld.kpmg.com"); //gsso.aspac.kpmg.com//sg.kworld.kpmg.com
                                                                                                                                      //  resolver.Credentials = new NetworkCredential(@"SG\engsooncheah", "Kpmg@singapore1331");
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.DtdProcessing = DtdProcessing.Parse;
                settings.ValidationType = ValidationType.DTD;

                settings.XmlResolver = resolver;


                XmlReader reader = XmlReader.Create(spurl, settings);
                //while (reader.Read())
                //{
                //    await turnContext.SendActivityAsync($"RBD: {reader.NodeType} -:- {reader.Name} -:- {reader.Value}");
                //}


                SyndicationFeed feed = SyndicationFeed.Load(reader);

                //ES22112019S
                reader.Close();

                var attachments = new List<Attachment>();
                foreach (SyndicationItem item in feed.Items)
                {
                    //Get Title,Description,URL
                    String title = item.Title.Text;
                    String description = item.Summary.Text;
                    String link = item.Links.FirstOrDefault().Uri.ToString();

                    //Hero Card
                    var heroCard = new HeroCard(
                        title: item.Title.Text,
                        subtitle: description,
                        buttons: new CardAction[]
                        {
                        new CardAction(ActionTypes.OpenUrl,"LINK",value:link)
                        }
                        ).ToAttachment();
                    attachments.Add(heroCard);

                }
                var reply = MessageFactory.Carousel(attachments);
                await turnContext.SendActivityAsync(reply);

            }
            catch (Exception ex)
            {
                await turnContext.SendActivityAsync(ex.ToString());
            }

            //-----------------------------------------------------------
            await turnContext.SendActivityAsync("Sample");
            try
            {
                string url = "https://azurecomcdn.azureedge.net/en-in/blog/topics/cognitive-services/feed/";
                XmlReader reader = XmlReader.Create(url);
                SyndicationFeed feed = SyndicationFeed.Load(reader);

                reader.Close();

                var attachments = new List<Attachment>();
                foreach (SyndicationItem item in feed.Items)
                {
                    //Get Title,Description,URL
                    String title = item.Title.Text;
                    //  String description = item.Summary.Text;
                    String link = item.Links.FirstOrDefault().Uri.ToString();
                    string newlink = link.Replace("\r\n", "");

                    //Hero Card
                    var heroCard = new HeroCard(
                        title: item.Title.Text,
                        // subtitle: description,
                        buttons: new CardAction[]
                        {
                        new CardAction(ActionTypes.OpenUrl,"LINK",value:link)
                        }
                        ).ToAttachment();
                    attachments.Add(heroCard);

                }
                var reply = MessageFactory.Carousel(attachments);
                await turnContext.SendActivityAsync(reply);
            }
            catch (Exception ex)
            {
                await turnContext.SendActivityAsync(ex.Message.ToString());
            }
        }



        private async Task ProcessSampleQnAAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            _logger.LogInformation("ProcessSampleQnAAsync");

            var results = await _botServices.SampleQnA.GetAnswersAsync(turnContext);
            if (results.Any())
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(results.First().Answer), cancellationToken);
                var answer = results.First().Answer;
                await ProcessCosmoDBStorageAsync(turnContext, answer, cancellationToken);
            }
            else
            {
                await turnContext.SendActivityAsync(MessageFactory.Text("Sorry, could not find an answer in the Q and A system."), cancellationToken);
            }
        }

        private async Task ProcessCosmoDBStorageAsync(ITurnContext<IMessageActivity> turnContext, string answer, CancellationToken cancellationToken)
        {
            // await turnContext.SendActivityAsync("Your answer"+answer.ToString());
            var userid = turnContext.Activity.From.Id;
            var resultsQnA = answer.ToString();
            var QuestionQnA = turnContext.Activity.Text;

            //  await turnContext.SendActivityAsync("Process Storage");

            UtteranceLog logItems = null;
            logItems = new UtteranceLog();
            logItems.UtteranceList.Add("UserId: " + userid + "," + "Question: " + QuestionQnA + "," + " Answer: " + resultsQnA);
            // set initial turn counter to 1.
            logItems.TurnNumber++;

            DateTime today = DateTime.Now;


            var changes = new Dictionary<string, object>();
            {
                changes.Add("QnA-" + today.ToString(), logItems);
            }
            try
            {
                // Save the user message to your Storage.
                await query.WriteAsync(changes, cancellationToken);
            }
            catch
            {
                // Inform the user an error occured.
                await turnContext.SendActivityAsync("Sorry, something went wrong storing your message!");
            }
        }
    }

}
