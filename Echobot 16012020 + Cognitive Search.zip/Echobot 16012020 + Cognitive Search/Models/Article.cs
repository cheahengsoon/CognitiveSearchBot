﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Models
{
    public class Article
    {
        public string Author { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public Uri link { get; set; }
        public Uri UrlToImage { get; set; }
        public string PublishedAt { get; set; }
    }
}
